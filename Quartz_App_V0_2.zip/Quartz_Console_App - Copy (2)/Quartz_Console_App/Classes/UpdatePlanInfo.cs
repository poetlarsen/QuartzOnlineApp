﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quartz_Console_App.Classes
{
    public class UpdatePlanInfo
    {
        public string Update_ID { get; set; }
        public string Department_Name { get; set; }
        public string Approved_By { get; set; }
        public DateTime Time { get; set; }
        public string Update_Reason { get; set; }
        public string Plan_ID { get; set; }
        public int Plan_Age { get; set; }
        public int Plan_Rating_Area { get; set; }
        public double New_Premium { get; set; }

      //  SELECT[Update_ID]
      //,[Department_Name]
      //,[Approved_By]
      //,[Time]
      //,[Update_Reason]
      //,[Plan_ID]
      //,[Plan_Age]
      //,[Plan_Rating_Area]
      //,[New_Premium]
      //  FROM[2018FA422_TeamB].[dbo].[Update_History]


    }
}
