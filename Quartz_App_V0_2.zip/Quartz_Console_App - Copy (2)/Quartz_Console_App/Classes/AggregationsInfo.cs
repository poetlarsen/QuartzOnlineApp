﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quartz_Console_App.Classes
{
    class PlanFrequency
    {
        public string Plan_ID { get; set; }
        public int Plan_Freq { get; set; }
        public double Total_Profits { get; set; }
    }
    class HospitalExpensesInfo
    {
        public string Name { get; set; }
        public double Total_Expense { get; set; }
    }
    class CustomerProfitsInfo
    {
        public string Customer_ID { get; set;  }
        public double Total_Profits { get; set; }
    }
    
}
