﻿using Dapper;
using Quartz_Console_App.Classes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Quartz_Console_App.DataInfo
{
    class Plans_Update_HistDAO
    {
        public IList<UpdatePlanInfo> Plans_Update_Hist()
        {
            IList<UpdatePlanInfo> Plans_Update_Hist;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"SELECT [Update_ID]
                                     ,[Department_Name]
                                     ,[Approved_By]
                                     ,[Time]
                                     ,[Update_Reason]
                                     ,[Plan_ID]
                                     ,[Plan_Age]
                                     ,[Plan_Rating_Area]
                                     ,[New_Premium]
                                 FROM [2018FA422_TeamB].[dbo].[Update_History]";
                Plans_Update_Hist = connection.Query<UpdatePlanInfo>(sql).AsList();
                connection.Close();
                return Plans_Update_Hist;
            }
        }
    }
}
