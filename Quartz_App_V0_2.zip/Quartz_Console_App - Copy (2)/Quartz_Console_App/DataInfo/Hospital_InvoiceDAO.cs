﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

//using System.Collections.Generic;
//using System.Configuration;
using System.Data.SqlClient;
using Quartz_Console_App.Classes;
using System.Data;

namespace Quartz_Console_App.DataInfo
{
    class Hospital_InvoiceDAO
    {
        public IList<QuartzInvoiceInfo> QuartzInvoiceHist()
        {
            IList<QuartzInvoiceInfo> Quartz_Invoice_Hist;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"SELECT Quartz_Invoice_ID, Amount_Paid, Paid_Date_Time, Department_Name,Hospital.Name, Hospital.Address,Hospital.City,Hospital.State
                                ,Hospital.Zip
                                 FROM [2018FA422_TeamB].[dbo].[Hospital_Invoice]
                                 INNER JOIN Hospital ON Hospital.Hospital_ID = Hospital_Invoice.Hospital_ID
                                 ORDER BY Quartz_Invoice_ID";
                Quartz_Invoice_Hist = connection.Query<QuartzInvoiceInfo>(sql).AsList();
                connection.Close();
                return Quartz_Invoice_Hist;
            }
        }
    }
}
