﻿using Dapper;
using Quartz_Console_App.Classes;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quartz_Console_App.DataInfo
{
    class Data_Aggregations
    {
        public IList<HospitalExpensesInfo> Yearly_Hospital_Expenses()
        {
            IList<HospitalExpensesInfo> Plans_Update_Hist;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"  SELECT Hospital.Name,SUM(Amount_Paid) AS Total_Expense FROM
   Hospital_Invoice INNER JOIN Hospital ON Hospital.Hospital_ID = Hospital_Invoice.Hospital_ID
    WHERE Paid_Date_Time > DATEADD(year,-1,GETDATE())
  GROUP BY(Hospital.Name)";
                Plans_Update_Hist = connection.Query<HospitalExpensesInfo>(sql).AsList();
                connection.Close();
                return Plans_Update_Hist;
            }
        }
        public double TotalExpenses()
        {
            double total = 0;
            using(var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"  SELECT SUM(Amount_Paid) AS Total_Expenses FROM Hospital_Invoice
WHERE Paid_Date_Time > DATEADD(year,-1,GETDATE())";

                total = (double)connection.ExecuteScalar(sql);
            }
            return total;
        }
        public IList<CustomerProfitsInfo> Yearly_Profits_By_Customer()
        {
            IList<CustomerProfitsInfo> Plans_Update_Hist;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"  
   SELECT Customer_ID,SUM(Paid_Amount) AS Total_Profits FROM Customer_Invoice
   WHERE Paid_Date_Time > DATEADD(year,-1,GETDATE())
  GROUP BY Customer_ID
  ORDER BY Total_Profits DESC

";
                Plans_Update_Hist = connection.Query<CustomerProfitsInfo>(sql).AsList();
                connection.Close();
                return Plans_Update_Hist;
            }
        }
        public double TotalProfits()
        {
            double total = 0;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"   SELECT SUM(Paid_Amount) AS Total_Profits FROM Customer_Invoice
   WHERE Paid_Date_Time > DATEADD(year,-1,GETDATE())";

                total = (double)connection.ExecuteScalar(sql);
            }
            return total;
        }

        public IList<PlanFrequency> Plan_Frequency()
        {
            IList<PlanFrequency> Plans_Update_Hist;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Quartz_Console_App"].ConnectionString))
            {
                connection.Open();
                string sql = @"  

  SELECT Plan_ID,COUNT(Plan_ID) AS Plan_Freq, SUM(Paid_Amount) AS Total_Profits FROM Customer_Invoice
    WHERE Paid_Date_Time > DATEADD(year,-1,GETDATE())
  GROUP BY Plan_ID
  ORDER BY Plan_Freq DESC, Total_Profits 

";
                Plans_Update_Hist = connection.Query<PlanFrequency>(sql).AsList();
                connection.Close();
                return Plans_Update_Hist;
            }
        }


    }
}
